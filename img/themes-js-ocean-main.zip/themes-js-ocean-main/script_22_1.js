// "use strict";

// // let a = [1, 2, 3];
// // let b = [...a];
// // b[0] = 8;
// // console.log(a);
// // // console.log(b);
// // var k = 2;
// // console.log(k);
// // function add(k, b) {
// //   k = 5;
// //   return k + b;
// // }
// // add(2, 3);
// // console.log(k);

// let a = 5;

// let b = `
// f
// ds
// fsdff
// fsdffsdfsdf
// sfsd ${a + 5}
// erty
// `;

// let k = " fdsfsadfdsa";

// // + - * / =

// // x=6;

// // x + 2 = x + 1;

// // x =

// // a = ++5; 1
// // b = 6--; -1
