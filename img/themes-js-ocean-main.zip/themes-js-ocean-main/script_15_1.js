// function pre4(nums) {
//   let n = [];

const newLocal = 1.28456;
//   nums.((el, i) => {
//     if (el == 4) {
//       return n;
//     } else {
//       n.push(nums[i]);
//     }
//   });
//   return n;

//   let ind = nums.indexOf(4);
//   return ind >= 0 ? nums.slice(0, ind) : nums;
// }

// console.log(pre4([1, 2, 1, 436, 324, 65]));

// let nnewLocal456;

// console.log(n.toFixed(2)); // 1.23
// console.log(Number(n.toFixed(1))); // 1.2345600000

// let sana = new Date();

// console.log(sana);

// let son = new Array(0);
// console.log(son);

// if () {
//   console.log(true);
// } else console.log(false);

// let billion = 1000000000;
// let billion1 = 12_323_435_435_734;

// console.log(billion);
// console.log(billion1);

// let billion = 1e-2; // 1 billion, literally: 1 and 9 zeroes
// console.log(Number(billion));
// console.log(7.3e9); // 7.3 billions (same as 7300000000 or 7_300_000_000)

// let a = 0b11111111; // binary form of 255
// let b = 0o377; // octal form of 255

// console.log(a == b); // true, the same number 255 at both sides

// let num = 16;

// console.log(num.toString(16)); // ff

// console.log(num.toString(36)); // 11111111

// let a = 4;

// alert((4.0).toString(36)); // 2n9c

// let a = -5.78;
// console.log(Math.trunc(a));

// let guestList = `Guests:
//  * John
//  * Pete
//  * Mary
// `;

// alert(guestList);

// let str = "Hello";

// alert(str[-2]); // undefined
// alert(str.at(-2)); // l

// let str = "Widget with id";

// console.log(str.indexOf("Widget")); // 0, because 'Widget' is found at the beginning
// console.log(str.indexOf("with")); // -1, not found, the search is case-sensitive
// console.log(str.indexOf("id")); // 1, "id" is found at the position 1 (..idget with id)

// let str = "Widget SaloM with id";
// // console.log(str);
// // console.log(str.indexOf("id", 2)); // 12

// console.log(str.includes("get  SaloM wi"));

// let a = "Assalomu alaykum, bugun dars bormi";

// if (a.endsWith("rahmat")) {
//   console.log("arzimaydi");
// } else {
//   console.log("Boshqa savolingiz bormi");
// }

// let str = "stringify";
// console.log(str.substring(6, 2)); // 'strin', the substring from 0 to 5 (not including 5)
// console.log(str.substring(2, 6)); // 'strin', the substring from 0 to 5 (not including 5)
// // console.log(str.substr(2, 6)); // 's', from 0 to 1, but not including 1, so only character at 0
