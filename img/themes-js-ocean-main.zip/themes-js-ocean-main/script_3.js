// console.log("here");

// let message = "hello";
// console.log("message tipi: ", typeof message);
// message = 123456;
// console.log("message tipi: ", typeof message);

// let n = 234567823456;
// n = 12.345;

// let cheksiz = -Infinity;

// console.log(cheksiz);

// console.log("cheksiz" * 2);

// alert(NaN + 1); // NaN
// alert(3 * NaN); // NaN
// alert("not a number" / 2 - 1); // NaN

// console.log(NaN ** 0);

// const bigInt = 1234567890123456789012345678901234567890n;
// console.log(bigInt * 123n);

// let str = "Hello";
// let str2 = "Single  quotes are ok too ${salom}";
// let phrase = `can  embed another  ${str2}  `;

// console.log(phrase);

// let name = "John";
// alert(`Hello, ${name}!`); // Hello, John!
// alert("the result is ${1 + 2}"); // the result is 3

// let nameFieldChecked = true; // yes, name field is checked
// let ageFieldChecked = false; // no, age field is not checked

// // console.log(nameFieldChecked);

// let truse = false;

// if (truse) {
//   console.log(true);
// } else {
//   console.log(false);
// }

// let isGreater = 4 > 1;
// console.log(isGreater); // true (the comparison result is "yes")

// let age;
// console.log(age);
// let age = 100; // change the value to undefined
// age = undefined;
// alert(age); // "undefined"

let son = 43534;
console.log(typeof son);

let soz = "43534";
console.log(typeof soz);

let bigINT = 43534n;
console.log(typeof bigINT);

let char = "n";
console.log(typeof char);

let nann = NaN;
console.log(typeof nann);

let aniqmas = undefined;
console.log(typeof aniqmas);

let boool = true;
console.log(typeof boool);

let simvol = Symbol;
console.log(typeof simvol);
