"use strict";

// no error

// int a = 45;

// a=78;

// let message = "hello";
// console.log(message);

// message = 123456;
// console.log(message);

// string matn = "dfasfsda";
// bool rostmi = true;

// let n = 52438953879;
// n = 12.345;

// 0.000000000000000000000001

// console.log("soz" * 1);

// alert(NaN + 1); // NaN
// alert(3 * NaN); // NaN
// alert("not a number" / 2 - 1); // NaN

// console.log(900719923245728937549375938475474099213n / 3487832723n);

// let a = 90071992532454740993n;
//

// let str = "Hello";
// let str2 = `Single quotes are ${str} ok too`;
// let phrase = `can embed another ${34 + 67 + 45345345 - 12321 / 45}`;

// console.log(phrase);

// let name = "John";
// alert(`Hello, ${name}!`); // Hello, John!
// alert(`the result is ${1 + 2}`); // the result is 3

// alert("the result is ${1 + 2}"); // the result is ${1 + 2} (double quotes do nothing)

// let isGreater = 4 == "4";
// console.log(isGreater); // true (the comparison result is "yes")

// let age = null;
// age = 56;
// console.log(age);

// let obj = {
//   ismi: "Muhammad",
//   yoshi: 56,
//   ismarried: true,
// };

// console.log(obj);

// let idf = Symbol;
// console.log(idf);

// let son = 4545;
// console.log(typeof son);

// let soz = "matn";
// console.log(typeof soz);

// let belgi = "w";
// console.log(typeof belgi);

// let boool = true;
// console.log(typeof boool);

// let naann = NaN;
// console.log(typeof naann);

// let aniqmas = undefined;
// console.log(typeof aniqmas);

// let nulish = null;
// console.log(typeof nulish);

// console.log(typeof obj);

// let ism = "Ilya";

// console.log(`hello ${1}`); // ?

// console.log(`hello ${"ism"}`); // ?

// console.log(`hello ${ism}`); // ?

// console.log(2 * 2 + 1);
