// let a = -8;

// if (a > 0) {
//   console.log("Musbat if");
// } else {
//   console.log("manfiy if");
// }

// a > 0 ? console.log("Musbat ternar") : console.log("manfiy ternar");
// shart ? rost_bolgadagijavob : aksholdaginatija

// let a = 1234;

// if (a == 1) {
//   console.log("1 ga teng");
// } else if (a == 2) {
//   console.log("2 ga teng");
// } else if (a == 3) {
//   console.log("3 ga teng");
// } else if (a == 4) {
//   console.log("4 ga teng");
// } else {
//   console.log("bunday son mavjud emas");
// }

// a == 1
//   ? console.log("1 ga teng")
//   : a == 2
//   ? console.log("2 ga teng")
//   : a == 3
//   ? console.log("3 ga teng")
//   : a == 4
//   ? console.log("4 ga teng")
//   : console.log("bunday son mavjud emas");

// while
// do while
// for

// for (let i = 0; i < 10; i++) {
//   console.log(i);
// }

// let a = 0;
// while (a) console.log("salom loop" + a--);

// let i = 0;

// do {
//   console.log("Salom llop" + i);
// } while (i);

// for (begin; condition; step) {
//   // ... loop body ...
// }
// let i = 0;
// for (i = 0; i <= 3; i++) {
//   // shows 0, then 1, then 2
//   console.log(i);
// }

// console.log(i);

// let i = 0; // we have i already declared and assigned
// for (; i < 3; ) {
//   // no need for "begin"
//   console.log(i); // 0, 1, 2
//   i++;

// }

// let i = 0;
// while (true) {
//   console.log(i);
//   i++;
//   if (i == 10) {
//     break;
//   }
// }

// let i = 0;
// while (i < 10) {
//   if (i % 2 == 0) {
//     i++;
//     continue;
//   }
//   i++;
//   console.log(i);
// }

// for (let i = 0; i < 10; i++) {
//   if (i % 2 == 0) continue;
//   console.log(i);
// }

// for (let i = 0; i < 10; i++) {
//   if (i % 2) {
//     console.log(i);
//   }
// }

// outer: for (let i = 0; i < 3; i++) {
//   for (let j = 0; j < 3; j++) {
//     let input = prompt(`Value at coords (${i},${j})`, "");
//     if (!input) {
//       break outer;
//     }
//     // what if we want to exit from here to Done (below)?
//   }
// }
// alert("Done!");

// delDel - Satr berilgan, agar "del" satrning 1-indeksdan boshlab paydo bo'lsa, o'sha "del" o'chirilgan yangi satr qaytaring. Aks holda, satrni o'zgarishsiz qaytaring.
