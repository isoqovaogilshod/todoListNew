// let aytilganGap = prompt("Aytdiki: ");

// (a,b,c)

// 1 1 1

// 1

// 1, 1 , 3

// 2

// 3899, 634, 8;

// 3 = 6
// 5 = 10

// console.log(mrQuloq(aytilganGap));

// function nomi(parametr1, parametr2 = "X") {
//   return parametr1 == parametr2;
// }

// console.log(nomi(7, 7));

// Sizga 3 ta son beriladi. Ular nechta turli sonlar ekanligini chop etuvchi dastur tuzing.

// function check3Number(a, b, c) {
//   let counter = 0;

//   if (a == b) counter++;
//   if (a == c) counter++;
//   if (b == c) counter++;

//   return counter == 0 ? 3 : counter == 1 ? 2 : 1;
// }

// console.log(check3Number(3, 3, 3));

// function engKichikJuftKarrali(a) {
//   let karrali = null;

//   return karrali;
// }

// engKichikJuftKarrali(3.0005); //60010;

// function check3Number(a, b, c) {
//   let counter = 0;
//   if (a == b) counter++;
//   if (b == c) counter++;
//   if (c == a) counter++;
//   return counter == 3 ? 1 : counter == 1 ? 2 : 3;

// }

// console.log(check3Number(3876543, 1, 234567));

// function check3Number(a, b, c) {
//   if (a == b && b == c && a == c) {
//     return 1;
//   } else if (a != b && b != c && a != c) {
//     return 3;
//   } else {
//     return 2;
//   }
// }

// console.log(check3Number(3, zz
