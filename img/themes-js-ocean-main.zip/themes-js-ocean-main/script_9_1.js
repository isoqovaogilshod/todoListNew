// kiritilgan kundna keyingi kunda keyingi kun

// let davomEtamizmi = true;

// while (davomEtamizmi) {
//   console.log("hello");

//   let day = +prompt("Kunni kiriting:");
//   let month = +prompt("Oyni kiriting:");

//   switch (month) {
//     case 1:
//       if (day <= 30 && day >= 1) console.log(++day + "-yanvar");
//       else console.log(1 + "-fevral");
//       break;
//     case 2:
//       if (day <= 27 && day >= 1) console.log(++day + "-fevral");
//       else console.log(1 + "-mart");

//       break;
//     case 3:
//       if (day <= 29 && day >= 1) console.log(++day + "-mart");
//       else console.log(1 + "-aprel");

//       break;

//     default:
//       break;
//   }

//   davomEtamizmi = confirm("Davom etamizmi");
// }

// let osh = "osh ";
