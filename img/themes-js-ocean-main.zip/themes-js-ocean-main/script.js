"use strict";

//o'zgaruvchilar nima uchun kerak?
//  nomi = qiymati // python
// boyi = 45
// tipi nomi = qiymati;
// int boyi = 45;

//let var const

// int son1=34, matn = "fdsjfsdlk";

// let message;

// message = "Salom xat";
// alert(message);
// let son1 = 23;
// let matn = "435643";
// let rost = true;
// let son3;

// son3 = 72;

// let hello = "Hello, world";
// let message;

// hello = "Hello, Dunyo";

// alert(hello);
// message = hello;
// alert(message);

// let $ = 1; // declared a variable with the name "$"
// let _ = 2; // and now a variable with the name "_"
// alert($ + _); // 3

// let имя = "...";
// let 我 = "...";

// let const = 45;

// const num = 5; // error: num is not defined

// num = 8;

let result;
let numberA, numberB;
numberA = 45;
numberB = 67;
result = numberA + numberB;
console.log("yi'gindi " + result);
result = numberA - numberB;
console.log("Ayirma " + result);

// Ikkita o'zgaruvchini e'lon qiling: admin va name.
// admin Qiymatni "John"ga o'zlashtiring.
// Qiymatni admin dan name ga nusxalang.
// name qiymatini ogohlantirish sifatida chiqaring.

let admin, name;

admin = "John";

name = admin;

alert(name);

// const birthday = '18.04.1982';
// const age = someCode(birthday);
