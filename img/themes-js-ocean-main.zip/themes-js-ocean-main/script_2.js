// "use strict";

// variables;
// o'zgaruvchilar

// let ism = "Muhammad";

// let matn = `Assalomu laykum`;

//let | var | const

// c++
// int float double string bool char
// tipi o'zgaruvchi_nomi = qiymati
// int a =45, b=67, c=45.78, d="name";

//js
// let|var|const o'zgaruvchi nomi = qiyamti

// let message1 = "Hello";
// var message2 = "Hello";

// let user = "John",
//   age = 25,
//   message3 = "Hello",
//   name = "matlanei ham yozishimiz mumkin";

// console.log(message);

// let message;
// message = "Hello!";
// console.log(message);
// message = "World!";
// console.log(message);

// let hello = "Hello world!";
// let message;

// console.log("Birinchi marta: " + message); // undefinded

// message = hello;
// console.log("Ikkinchi marta: " + message); // Hello world

// let message = "This"; // repeated 'let' leads to an error
// let message2 = "That"; // SyntaxError: 'message' has already been declared

// let $_user_Name_;
// let test123;

// let myVeryLongName = "MuhammadAbdulloh";

// let $ = 1; // declared a variable with the name "$"
// let _ = 2; // and now a variable with the name "_"
// console.log($ + _); // 3
// let 1a;

// let apple, appLe, APPLE, Apple, APple, APPle;

// let имя = "...";
// let 我 = "...";

// let switch = 56;

// let num = 5;

// Doimiy (o'zgarmas) o'zgaruvchini e'lon qilish uchun consto'rniga foydalaning let:

// const myBirthday = "18.04.1982";

// myBirthday = "01.01.2001"; // error, can't reassign the constant!

// const COLOR_RED = "#F00";
// const COLOR_GREEN = "#0F0";
// const COLOR_BLUE = "#00F";
// const COLOR_ORANGE = "#FF7F00";
// // ...when we need to pick a colorlet
// color = COLOR_ORANGE;
// alert(color); // #FF7F00

// let num = 67;
// let num2 = 89;

let answer;
let numberA, numberB;
numberA = prompt("A soni");
numberB = prompt("B soni");

answer = numberA * 1 + numberB * 1;
console.log("Yig'indi=" + answer);
answer = numberA - numberB;
console.log("Ayirma=" + answer);
answer = numberA * 1 * numberB * 1;
console.log("Ko'paytma=" + answer);
answer = numberA / numberB;
console.log("Bo'linma=" + answer);

// 1) yi'gindi bo'linma ko'paytma ayirmasini chiqarish
// 2) a va b sonlarini foydalanuvchi kiritsin
